############################################################
# PROCESAMIENTO Y VISUALIZACIÓN DE DATOS EN R
# AYUDANTÍA 1 - SCRIPT 02
#
# Galería compacta de tablas, gráficos y salidas exportables
#
# Objetivo:
# Cargar la base procesada creada en el script anterior y
# producir una galería breve de tablas y gráficos útiles para
# informes académicos.
#
# Este script NO simula ni limpia la base desde cero.
# Parte desde:
# output/datos_proc_final_movilidad_bienestar.RData
# o, si no existe:
# output/datos_proc_final_movilidad_bienestar.csv
#
# Tema:
# Movilidad cotidiana, uso del tiempo, bienestar y vida adulta.
############################################################


############################################################
# 0. LIMPIEZA DEL ENTORNO
############################################################

rm(list = ls())
options(scipen = 999)


############################################################
# 1. CARGA DE PAQUETES
############################################################

if (!require(pacman)) {
  install.packages("pacman")
}

pacman::p_load(
  tidyverse,   # manipulación de datos
  ggplot2,     # gráficos
  scales,      # porcentajes y formatos
  janitor,     # tablas simples
  gt,          # tablas bonitas para informes/html
  gtsummary,   # tablas tipo artículo
  openxlsx,    # exportar Excel con formato
  patchwork,   # unir gráficos
  gridExtra    # exportar tablas como PNG sin depender de Chrome
)


############################################################
# 2. CREAR CARPETAS DE SALIDA
############################################################

dir.create("output/graficos", showWarnings = FALSE, recursive = TRUE)
dir.create("output/tablas", showWarnings = FALSE, recursive = TRUE)
dir.create("output/tablas/html", showWarnings = FALSE, recursive = TRUE)
dir.create("output/tablas/png", showWarnings = FALSE, recursive = TRUE)
dir.create("output/tablas/excel", showWarnings = FALSE, recursive = TRUE)
dir.create("output/tablas/csv", showWarnings = FALSE, recursive = TRUE)


############################################################
# 3. CARGAR BASE PROCESADA DEL SCRIPT ANTERIOR
############################################################

# Este script continúa desde la base procesada del script anterior.
# Primero intenta cargar el .RData. Si no existe, intenta cargar el .csv.

archivo_rdata <- "output/datos_proc_final_movilidad_bienestar.RData"
archivo_csv   <- "output/datos_proc_final_movilidad_bienestar.csv"

if (file.exists(archivo_rdata)) {
  
  objetos_cargados <- load(archivo_rdata)
  
  if (!"datos_proc" %in% objetos_cargados) {
    if (length(objetos_cargados) == 1) {
      datos_proc <- get(objetos_cargados[1])
    } else {
      stop("El archivo .RData no contiene un objeto llamado datos_proc.")
    }
  }
  
} else if (file.exists(archivo_csv)) {
  
  datos_proc <- read_csv(archivo_csv)
  
} else {
  
  stop("No se encontró la base procesada. Ejecuta primero el script anterior.")
}

# Revisión rápida de la base.
names(datos_proc)
dim(datos_proc)
summary(datos_proc)


############################################################
# 4. VERIFICAR VARIABLES NECESARIAS
############################################################

# Este bloque evita errores como:
# objeto 'modalidad_cat' no encontrado.
#
# El script se ajusta a la base actual, que contiene variables como:
# situacion_laboral_cat, carga_movilidad_tiempo y bienestar_general.

variables_necesarias <- c(
  "id",
  "edad",
  "genero",
  "zona_residencia",
  "situacion_laboral",
  "transporte_principal",
  "tiempo_traslado_min",
  "horas_sueno",
  "actividad_fisica_sem",
  "horas_redes_dia",
  "participacion_social",
  "confianza_vecinal",
  "estres_cotidiano",
  "bienestar_general",
  "satisfaccion_tiempo_libre",
  "zona_cat",
  "situacion_laboral_cat",
  "transporte_cat",
  "participacion_cat",
  "confianza_cat",
  "estres_cat",
  "satisfaccion_tiempo_cat",
  "carga_movilidad_tiempo",
  "bienestar_cat",
  "actividad_fisica_cat"
)

variables_faltantes <- setdiff(variables_necesarias, names(datos_proc))

if (length(variables_faltantes) > 0) {
  stop(
    paste(
      "Faltan estas variables en datos_proc:",
      paste(variables_faltantes, collapse = ", ")
    )
  )
}


############################################################
# 5. ASEGURAR TIPOS DE VARIABLES
############################################################

# Si la base viene desde CSV, algunas variables numéricas pueden
# cargarse como texto. Aquí nos aseguramos de que las variables
# cuantitativas queden como numéricas.

vars_numericas <- c(
  "edad",
  "tiempo_traslado_min",
  "horas_sueno",
  "actividad_fisica_sem",
  "horas_redes_dia",
  "participacion_social",
  "confianza_vecinal",
  "estres_cotidiano",
  "bienestar_general",
  "satisfaccion_tiempo_libre"
)

datos_proc <- datos_proc %>%
  mutate(
    across(
      all_of(vars_numericas),
      ~ suppressWarnings(as.numeric(.x))
    )
  )

# También ordenamos algunas variables categóricas para que las tablas
# y gráficos salgan en un orden más interpretativo.

datos_proc <- datos_proc %>%
  mutate(
    bienestar_cat = factor(
      bienestar_cat,
      levels = c("Bienestar bajo", "Bienestar medio", "Bienestar alto"),
      ordered = TRUE
    ),
    
    estres_cat = factor(
      estres_cat,
      levels = c("Muy bajo", "Bajo", "Medio", "Alto", "Muy alto"),
      ordered = TRUE
    ),
    
    satisfaccion_tiempo_cat = factor(
      satisfaccion_tiempo_cat,
      levels = c("Muy baja", "Baja", "Media", "Alta", "Muy alta"),
      ordered = TRUE
    ),
    
    carga_movilidad_tiempo = factor(
      carga_movilidad_tiempo,
      levels = c("Carga moderada o baja", "Alta carga cotidiana")
    ),
    
    actividad_fisica_cat = factor(
      actividad_fisica_cat,
      levels = c("Actividad baja", "Actividad moderada o alta")
    )
  )


############################################################
# 6. ESTILO GENERAL PARA GRÁFICOS
############################################################

# Guardar los gráficos como objetos permite revisarlos,
# modificarlos y exportarlos con ggsave().

theme_ayudantia <- function(base_size = 12) {
  theme_minimal(base_size = base_size) +
    theme(
      plot.title = element_text(face = "bold", size = base_size + 3),
      plot.subtitle = element_text(size = base_size, color = "gray30"),
      plot.caption = element_text(size = base_size - 2, color = "gray40"),
      axis.title = element_text(face = "bold"),
      axis.text.x = element_text(angle = 15, hjust = 1),
      panel.grid.minor = element_blank(),
      legend.title = element_text(face = "bold")
    )
}

# Función para crear paletas según las categorías reales de la base.
crear_paleta <- function(x, preferidos = NULL) {
  
  categorias <- sort(unique(na.omit(as.character(x))))
  
  colores_base <- c(
    "#4E79A7",
    "#F28E2B",
    "#59A14F",
    "#E15759",
    "#76B7B2",
    "#EDC948",
    "#B07AA1",
    "#9C755F"
  )
  
  paleta <- setNames(
    colores_base[seq_along(categorias)],
    categorias
  )
  
  if (!is.null(preferidos)) {
    comunes <- intersect(names(preferidos), names(paleta))
    paleta[comunes] <- preferidos[comunes]
  }
  
  return(paleta)
}

pal_situacion <- crear_paleta(datos_proc$situacion_laboral_cat)

pal_carga <- crear_paleta(
  datos_proc$carga_movilidad_tiempo,
  preferidos = c(
    "Carga moderada o baja" = "#4E79A7",
    "Alta carga cotidiana" = "#E15759"
  )
)


############################################################
# 7. FUNCIONES AUXILIARES PARA GUARDAR TABLAS
############################################################

guardar_gt_html <- function(tabla_gt, archivo_html) {
  gt::gtsave(
    data = tabla_gt,
    filename = archivo_html
  )
}

guardar_tabla_png <- function(tabla,
                              archivo,
                              titulo = NULL,
                              width = 1600,
                              height = 900,
                              res = 200) {
  
  png(
    filename = archivo,
    width = width,
    height = height,
    res = res
  )
  
  grid::grid.newpage()
  
  tabla_grob <- gridExtra::tableGrob(
    tabla,
    rows = NULL,
    theme = gridExtra::ttheme_minimal(
      base_size = 9,
      core = list(
        fg_params = list(hjust = 0, x = 0.03)
      ),
      colhead = list(
        fg_params = list(fontface = "bold", col = "white"),
        bg_params = list(fill = "#2F3A45", col = NA)
      )
    )
  )
  
  if (!is.null(titulo)) {
    
    titulo_grob <- grid::textGrob(
      titulo,
      gp = grid::gpar(fontsize = 14, fontface = "bold")
    )
    
    grid::grid.draw(
      gridExtra::arrangeGrob(
        titulo_grob,
        tabla_grob,
        ncol = 1,
        heights = c(0.15, 0.85)
      )
    )
    
  } else {
    
    grid::grid.draw(tabla_grob)
  }
  
  dev.off()
}


############################################################
# 8. GALERÍA COMPACTA DE TABLAS PARA INFORMES
############################################################

# La idea es mostrar distintos tipos de salida:
#
# 1. Tabla ejecutiva en gt + PNG
# 2. Frecuencia simple como gráfico-tabla
# 3. Tabla ordinal acumulada
# 4. Descriptivos por grupo
# 5. Cruce categórico como mapa-tabla
# 6. Tabla tipo artículo con gtsummary
# 7. Excel final con todas las tablas base
# 8. Un CSV de ejemplo


############################################################
# 8.1 TABLA 1: RESUMEN EJECUTIVO EN GT + PNG
############################################################

tabla_01_resumen <- tibble(
  Indicador = c(
    "Total de personas",
    "Edad promedio",
    "% mujeres",
    "% alta carga cotidiana",
    "Promedio tiempo de traslado",
    "Promedio horas de sueño",
    "Promedio horas en redes",
    "Bienestar promedio"
  ),
  
  Valor = c(
    nrow(datos_proc),
    mean(datos_proc$edad, na.rm = TRUE),
    mean(datos_proc$genero == "Mujer", na.rm = TRUE) * 100,
    mean(datos_proc$carga_movilidad_tiempo == "Alta carga cotidiana", na.rm = TRUE) * 100,
    mean(datos_proc$tiempo_traslado_min, na.rm = TRUE),
    mean(datos_proc$horas_sueno, na.rm = TRUE),
    mean(datos_proc$horas_redes_dia, na.rm = TRUE),
    mean(datos_proc$bienestar_general, na.rm = TRUE)
  )
) %>%
  mutate(Valor = round(Valor, 2))

tabla_01_gt <- tabla_01_resumen %>%
  gt() %>%
  tab_header(
    title = md("**Resumen ejecutivo de la muestra**"),
    subtitle = "Indicadores principales sobre movilidad, uso del tiempo y bienestar"
  ) %>%
  fmt_number(
    columns = Valor,
    decimals = 2
  ) %>%
  cols_label(
    Indicador = "Indicador",
    Valor = "Valor"
  ) %>%
  tab_source_note(
    source_note = "Fuente: base simulada de ayudantía."
  ) %>%
  tab_options(
    table.font.names = "Arial",
    heading.title.font.size = 16,
    heading.subtitle.font.size = 12,
    column_labels.font.weight = "bold"
  )

tabla_01_gt

guardar_gt_html(
  tabla_gt = tabla_01_gt,
  archivo_html = "output/tablas/html/tabla_01_resumen_muestra.html"
)

guardar_tabla_png(
  tabla = tabla_01_resumen,
  archivo = "output/tablas/png/tabla_01_resumen_muestra.png",
  titulo = "Resumen ejecutivo de la muestra",
  width = 1500,
  height = 750
)


############################################################
# 8.2 TABLA 2: FRECUENCIA SIMPLE COMO GRÁFICO-TABLA
############################################################

# Frecuencia = número de casos en cada categoría.
# Porcentaje = peso relativo de cada categoría sobre el total.

tabla_02_frecuencia <- datos_proc %>%
  filter(!is.na(situacion_laboral_cat)) %>%
  janitor::tabyl(situacion_laboral_cat) %>%
  as_tibble() %>%
  transmute(
    Categoria = situacion_laboral_cat,
    Frecuencia = n,
    Porcentaje = round(percent * 100, 1),
    Etiqueta = paste0(n, " casos\n", round(percent * 100, 1), "%")
  )

graf_tabla_02 <- ggplot(
  tabla_02_frecuencia,
  aes(x = Categoria, y = Porcentaje / 100, fill = Categoria)
) +
  geom_col(width = 0.6) +
  geom_text(
    aes(label = Etiqueta),
    vjust = -0.3,
    size = 4
  ) +
  scale_y_continuous(
    labels = percent_format(),
    expand = expansion(mult = c(0, 0.15))
  ) +
  scale_fill_manual(values = pal_situacion) +
  labs(
    title = "Situación laboral de las personas encuestadas",
    subtitle = "Frecuencia y porcentaje por categoría",
    x = "Situación laboral",
    y = "Porcentaje",
    caption = "Fuente: base simulada de ayudantía."
  ) +
  theme_ayudantia() +
  theme(legend.position = "none")

graf_tabla_02

ggsave(
  filename = "output/tablas/png/tabla_02_frecuencia_situacion_laboral_grafica.png",
  plot = graf_tabla_02,
  width = 9,
  height = 5.5,
  dpi = 300
)


############################################################
# 8.3 TABLA 3: VARIABLE ORDINAL CON PORCENTAJE ACUMULADO
############################################################

tabla_03_ordinal <- datos_proc %>%
  filter(!is.na(bienestar_cat)) %>%
  count(bienestar_cat, name = "Frecuencia") %>%
  mutate(
    Porcentaje = Frecuencia / sum(Frecuencia) * 100,
    `Porcentaje acumulado` = cumsum(Porcentaje),
    Porcentaje = round(Porcentaje, 1),
    `Porcentaje acumulado` = round(`Porcentaje acumulado`, 1)
  ) %>%
  rename(
    `Nivel de bienestar` = bienestar_cat
  )

tabla_03_gt <- tabla_03_ordinal %>%
  gt() %>%
  tab_header(
    title = md("**Distribución ordinal del bienestar general**"),
    subtitle = "Frecuencia, porcentaje y porcentaje acumulado"
  ) %>%
  fmt_number(
    columns = c(Porcentaje, `Porcentaje acumulado`),
    decimals = 1
  ) %>%
  tab_source_note(
    source_note = "Fuente: base simulada de ayudantía."
  ) %>%
  tab_options(
    table.font.names = "Arial",
    heading.title.font.size = 16,
    heading.subtitle.font.size = 12,
    column_labels.font.weight = "bold"
  )

tabla_03_gt

guardar_gt_html(
  tabla_gt = tabla_03_gt,
  archivo_html = "output/tablas/html/tabla_03_bienestar_acumulado.html"
)

guardar_tabla_png(
  tabla = tabla_03_ordinal,
  archivo = "output/tablas/png/tabla_03_bienestar_acumulado.png",
  titulo = "Distribución ordinal del bienestar general",
  width = 1600,
  height = 800
)


############################################################
# 8.4 TABLA 4: DESCRIPTIVOS POR GRUPO EN GT + PNG
############################################################

# Esta tabla compara grupos.
# Aquí se compara según situación laboral.

tabla_04_descriptivos <- datos_proc %>%
  filter(!is.na(situacion_laboral_cat)) %>%
  group_by(situacion_laboral_cat) %>%
  summarise(
    N = n(),
    `Media traslado` = mean(tiempo_traslado_min, na.rm = TRUE),
    `Media sueño` = mean(horas_sueno, na.rm = TRUE),
    `Media redes` = mean(horas_redes_dia, na.rm = TRUE),
    `Media actividad física` = mean(actividad_fisica_sem, na.rm = TRUE),
    `Media estrés` = mean(estres_cotidiano, na.rm = TRUE),
    `Media bienestar` = mean(bienestar_general, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  rename(
    `Situación laboral` = situacion_laboral_cat
  )

tabla_04_gt <- tabla_04_descriptivos %>%
  gt() %>%
  tab_header(
    title = md("**Descriptivos según situación laboral**"),
    subtitle = "Movilidad, descanso, redes, actividad física, estrés y bienestar"
  ) %>%
  fmt_number(
    columns = where(is.numeric),
    decimals = 2
  ) %>%
  tab_source_note(
    source_note = "Fuente: base simulada de ayudantía."
  ) %>%
  tab_options(
    table.font.names = "Arial",
    heading.title.font.size = 16,
    heading.subtitle.font.size = 12,
    column_labels.font.weight = "bold"
  )

tabla_04_gt

guardar_gt_html(
  tabla_gt = tabla_04_gt,
  archivo_html = "output/tablas/html/tabla_04_descriptivos_por_situacion_laboral.html"
)

guardar_tabla_png(
  tabla = tabla_04_descriptivos,
  archivo = "output/tablas/png/tabla_04_descriptivos_por_situacion_laboral.png",
  titulo = "Descriptivos según situación laboral",
  width = 2300,
  height = 900
)


############################################################
# 8.5 TABLA 5: CRUCE CATEGÓRICO COMO MAPA-TABLA
############################################################

# Esta salida combina tabla y gráfico.
# El porcentaje por fila responde:
# dentro de cada grupo de carga, ¿cómo se distribuye el bienestar?

tabla_05_cruce_larga <- datos_proc %>%
  filter(!is.na(carga_movilidad_tiempo), !is.na(bienestar_cat)) %>%
  count(
    carga_movilidad_tiempo,
    bienestar_cat,
    name = "Frecuencia",
    .drop = FALSE
  ) %>%
  group_by(carga_movilidad_tiempo) %>%
  mutate(
    Porcentaje = Frecuencia / sum(Frecuencia),
    Etiqueta = paste0(Frecuencia, "\n(", percent(Porcentaje, accuracy = 0.1), ")")
  ) %>%
  ungroup()

graf_tabla_05 <- ggplot(
  tabla_05_cruce_larga,
  aes(x = bienestar_cat, y = carga_movilidad_tiempo, fill = Porcentaje)
) +
  geom_tile(color = "white", linewidth = 1) +
  geom_text(aes(label = Etiqueta), size = 4) +
  scale_fill_gradient(
    low = "#F7FBFF",
    high = "#4E79A7",
    labels = percent_format()
  ) +
  labs(
    title = "Bienestar general según carga cotidiana",
    subtitle = "Cada celda muestra frecuencia y porcentaje por fila",
    x = "Nivel de bienestar",
    y = "Carga cotidiana",
    fill = "% por fila",
    caption = "Fuente: base simulada de ayudantía."
  ) +
  theme_ayudantia() +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 0.5),
    panel.grid = element_blank()
  )

graf_tabla_05

ggsave(
  filename = "output/tablas/png/tabla_05_cruce_carga_bienestar_mapa.png",
  plot = graf_tabla_05,
  width = 9,
  height = 5,
  dpi = 300
)

tabla_05_cruce_excel <- tabla_05_cruce_larga %>%
  mutate(
    Celda = paste0(Frecuencia, " (", percent(Porcentaje, accuracy = 0.1), ")")
  ) %>%
  select(carga_movilidad_tiempo, bienestar_cat, Celda) %>%
  pivot_wider(
    names_from = bienestar_cat,
    values_from = Celda
  ) %>%
  rename(
    `Carga cotidiana` = carga_movilidad_tiempo
  )


############################################################
# 8.6 TABLA 6: TABLA TIPO ARTÍCULO CON GTSUMMARY
############################################################

tabla_06_articulo <- datos_proc %>%
  select(
    situacion_laboral_cat,
    genero,
    edad,
    zona_cat,
    transporte_cat,
    tiempo_traslado_min,
    horas_sueno,
    actividad_fisica_sem,
    horas_redes_dia,
    actividad_fisica_cat,
    estres_cat,
    participacion_cat,
    confianza_cat,
    bienestar_general,
    bienestar_cat,
    satisfaccion_tiempo_cat,
    carga_movilidad_tiempo
  ) %>%
  tbl_summary(
    by = situacion_laboral_cat,
    statistic = list(
      all_continuous() ~ "{mean} ({sd})",
      all_categorical() ~ "{n} ({p}%)"
    ),
    digits = all_continuous() ~ 2,
    missing = "no"
  ) %>%
  add_overall() %>%
  modify_header(
    label ~ "**Variable**"
  ) %>%
  modify_caption(
    "**Tabla descriptiva de la muestra según situación laboral**"
  )

tabla_06_articulo

tabla_06_articulo_gt <- as_gt(tabla_06_articulo)

guardar_gt_html(
  tabla_gt = tabla_06_articulo_gt,
  archivo_html = "output/tablas/html/tabla_06_gtsummary_articulo.html"
)

tabla_06_articulo_excel <- tryCatch(
  {
    as_tibble(tabla_06_articulo, col_labels = TRUE)
  },
  error = function(e) {
    tabla_06_articulo$table_body
  }
) %>%
  mutate(across(everything(), as.character))


############################################################
# 8.7 UN SOLO CSV DE EJEMPLO
############################################################

write_csv(
  tabla_01_resumen,
  "output/tablas/csv/tabla_01_resumen_muestra_ejemplo.csv"
)


############################################################
# 8.8 EXCEL FINAL CON TODAS LAS TABLAS BASE
############################################################

wb <- createWorkbook()

estilo_header <- createStyle(
  textDecoration = "bold",
  fontColour = "white",
  fgFill = "#2F3A45",
  halign = "center"
)

agregar_hoja <- function(wb, hoja, tabla) {
  
  addWorksheet(wb, hoja)
  
  writeDataTable(
    wb,
    sheet = hoja,
    x = tabla,
    startRow = 1,
    startCol = 1,
    tableStyle = "TableStyleMedium2",
    withFilter = TRUE
  )
  
  addStyle(
    wb,
    sheet = hoja,
    style = estilo_header,
    rows = 1,
    cols = 1:ncol(tabla),
    gridExpand = TRUE
  )
  
  setColWidths(
    wb,
    sheet = hoja,
    cols = 1:ncol(tabla),
    widths = "auto"
  )
  
  freezePane(
    wb,
    sheet = hoja,
    firstActiveRow = 2
  )
}

agregar_hoja(wb, "Resumen", tabla_01_resumen)
agregar_hoja(wb, "Frecuencia", tabla_02_frecuencia)
agregar_hoja(wb, "Ordinal", tabla_03_ordinal)
agregar_hoja(wb, "Descriptivos", tabla_04_descriptivos)
agregar_hoja(wb, "Cruce", tabla_05_cruce_excel)
agregar_hoja(wb, "Articulo", tabla_06_articulo_excel)

saveWorkbook(
  wb,
  file = "output/tablas/excel/galeria_tablas_ayudantia.xlsx",
  overwrite = TRUE
)


############################################################
# 9. GALERÍA COMPACTA DE VISUALIZACIONES
############################################################


############################################################
# 9.1 GRÁFICO 1: BARRAS CON PORCENTAJE
############################################################

graf_01_barras <- datos_proc %>%
  filter(!is.na(situacion_laboral_cat)) %>%
  count(situacion_laboral_cat) %>%
  mutate(
    porcentaje = n / sum(n),
    etiqueta = percent(porcentaje, accuracy = 0.1)
  ) %>%
  ggplot(aes(x = situacion_laboral_cat, y = porcentaje, fill = situacion_laboral_cat)) +
  geom_col(width = 0.65) +
  geom_text(
    aes(label = etiqueta),
    vjust = -0.4,
    size = 4
  ) +
  scale_y_continuous(
    labels = percent_format(),
    expand = expansion(mult = c(0, 0.15))
  ) +
  scale_fill_manual(values = pal_situacion) +
  labs(
    title = "Distribución según situación laboral",
    subtitle = "Porcentaje de personas por categoría",
    x = "Situación laboral",
    y = "Porcentaje",
    caption = "Fuente: base simulada de ayudantía."
  ) +
  theme_ayudantia() +
  theme(legend.position = "none")

graf_01_barras

ggsave(
  filename = "output/graficos/01_barras_situacion_laboral_porcentaje.png",
  plot = graf_01_barras,
  width = 9,
  height = 5.5,
  dpi = 300
)


############################################################
# 9.2 GRÁFICO 2: HISTOGRAMA CON MEDIA
############################################################

graf_02_histograma <- datos_proc %>%
  filter(!is.na(bienestar_general)) %>%
  ggplot(aes(x = bienestar_general)) +
  geom_histogram(
    bins = 12,
    fill = "#4E79A7",
    color = "white"
  ) +
  geom_vline(
    aes(xintercept = mean(bienestar_general, na.rm = TRUE)),
    linetype = "dashed",
    linewidth = 1
  ) +
  labs(
    title = "Distribución del bienestar general",
    subtitle = "La línea punteada indica la media",
    x = "Bienestar general",
    y = "Frecuencia",
    caption = "Fuente: base simulada de ayudantía."
  ) +
  theme_ayudantia()

graf_02_histograma

ggsave(
  filename = "output/graficos/02_histograma_bienestar_general.png",
  plot = graf_02_histograma,
  width = 8,
  height = 5,
  dpi = 300
)


############################################################
# 9.3 GRÁFICO 3: BOXPLOT CON PUNTOS INDIVIDUALES
############################################################

graf_03_boxplot <- datos_proc %>%
  filter(!is.na(situacion_laboral_cat), !is.na(bienestar_general)) %>%
  ggplot(aes(x = situacion_laboral_cat, y = bienestar_general, fill = situacion_laboral_cat)) +
  geom_boxplot(alpha = 0.75, outlier.shape = NA) +
  geom_jitter(
    width = 0.12,
    alpha = 0.45,
    size = 2
  ) +
  scale_fill_manual(values = pal_situacion) +
  labs(
    title = "Bienestar general según situación laboral",
    subtitle = "Boxplot con observaciones individuales",
    x = "Situación laboral",
    y = "Bienestar general",
    caption = "Fuente: base simulada de ayudantía."
  ) +
  theme_ayudantia() +
  theme(legend.position = "none")

graf_03_boxplot

ggsave(
  filename = "output/graficos/03_boxplot_bienestar_situacion_laboral.png",
  plot = graf_03_boxplot,
  width = 9,
  height = 5.5,
  dpi = 300
)


############################################################
# 9.4 GRÁFICO 4: DISPERSIÓN ENTRE DOS VARIABLES NUMÉRICAS
############################################################

graf_04_dispersion <- datos_proc %>%
  filter(
    !is.na(horas_redes_dia),
    !is.na(bienestar_general),
    !is.na(situacion_laboral_cat)
  ) %>%
  ggplot(aes(x = horas_redes_dia, y = bienestar_general, color = situacion_laboral_cat)) +
  geom_point(alpha = 0.75, size = 2.4) +
  geom_smooth(method = "lm", se = FALSE) +
  scale_color_manual(values = pal_situacion) +
  labs(
    title = "Horas en redes y bienestar general",
    subtitle = "Relación descriptiva, no causal",
    x = "Horas diarias en redes",
    y = "Bienestar general",
    color = "Situación laboral",
    caption = "Fuente: base simulada de ayudantía."
  ) +
  theme_ayudantia()

graf_04_dispersion

ggsave(
  filename = "output/graficos/04_dispersion_redes_bienestar.png",
  plot = graf_04_dispersion,
  width = 9,
  height = 5.5,
  dpi = 300
)


############################################################
# 9.5 GRÁFICO 5: BARRAS AGRUPADAS
############################################################

graf_05_barras_agrupadas <- datos_proc %>%
  filter(!is.na(carga_movilidad_tiempo), !is.na(bienestar_cat)) %>%
  count(carga_movilidad_tiempo, bienestar_cat) %>%
  group_by(carga_movilidad_tiempo) %>%
  mutate(
    porcentaje = n / sum(n)
  ) %>%
  ungroup() %>%
  ggplot(aes(x = bienestar_cat, y = porcentaje, fill = carga_movilidad_tiempo)) +
  geom_col(
    position = position_dodge(width = 0.8),
    width = 0.7
  ) +
  scale_y_continuous(labels = percent_format()) +
  scale_fill_manual(values = pal_carga) +
  labs(
    title = "Bienestar general según carga cotidiana",
    subtitle = "Porcentajes calculados dentro de cada grupo de carga",
    x = "Nivel de bienestar",
    y = "Porcentaje dentro del grupo",
    fill = "Carga cotidiana",
    caption = "Fuente: base simulada de ayudantía."
  ) +
  theme_ayudantia()

graf_05_barras_agrupadas

ggsave(
  filename = "output/graficos/05_barras_agrupadas_bienestar_carga.png",
  plot = graf_05_barras_agrupadas,
  width = 9,
  height = 5,
  dpi = 300
)


############################################################
# 9.6 GRÁFICO 6: BOXPLOT DE HORAS DE SUEÑO SEGÚN CARGA
############################################################

graf_06_sueno_carga <- datos_proc %>%
  filter(!is.na(carga_movilidad_tiempo), !is.na(horas_sueno)) %>%
  ggplot(aes(x = carga_movilidad_tiempo, y = horas_sueno, fill = carga_movilidad_tiempo)) +
  geom_boxplot(alpha = 0.75, outlier.shape = NA) +
  geom_jitter(
    width = 0.12,
    alpha = 0.45,
    size = 2
  ) +
  scale_fill_manual(values = pal_carga) +
  labs(
    title = "Horas de sueño según carga cotidiana",
    subtitle = "Comparación descriptiva entre grupos",
    x = "Carga cotidiana",
    y = "Horas de sueño diario",
    caption = "Fuente: base simulada de ayudantía."
  ) +
  theme_ayudantia() +
  theme(legend.position = "none")

graf_06_sueno_carga

ggsave(
  filename = "output/graficos/06_boxplot_sueno_carga.png",
  plot = graf_06_sueno_carga,
  width = 8,
  height = 5,
  dpi = 300
)


############################################################
# 9.7 GRÁFICO 7: PANEL RESUMEN
############################################################

panel_galeria <- (graf_01_barras + graf_02_histograma) /
  (graf_03_boxplot + graf_04_dispersion) +
  plot_annotation(
    title = "Galería breve de visualizaciones",
    subtitle = "Situación laboral, bienestar, redes y carga cotidiana",
    caption = "Fuente: base simulada de ayudantía."
  )

panel_galeria

ggsave(
  filename = "output/graficos/07_panel_galeria_visualizaciones.png",
  plot = panel_galeria,
  width = 12,
  height = 9,
  dpi = 300
)


############################################################
# 10. REVISAR ARCHIVOS EXPORTADOS
############################################################

list.files("output/tablas", recursive = TRUE)
list.files("output/graficos")


############################################################
# FIN DEL SCRIPT
############################################################